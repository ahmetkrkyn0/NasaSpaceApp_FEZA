# Lunar site -> Sun/Earth az/el with SpiceyPy (>=8.x, CSPICE N0067). Kernels from NAIF generic_kernels.
import numpy as np, spiceypy as sp
for k in ["naif0012.tls", "de440s.bsp", "pck00011.tpc", "moon_pa_de440_200625.bpc",
          "moon_de440_250416.tf", "moon_assoc_me.tf"]:
    sp.furnsh(k)
LAT, LON, H = -84.78, 29.13, 0.0                  # MOON_ME (LOLA/QuickMap), deg, deg, km
re, _, rp = sp.bodvrd("MOON", "RADII", 3)[1]      # pck00011 -> 1737.4 km sphere
site = sp.georec(np.radians(LON), np.radians(LAT), H, re, (re - rp) / re)
et0 = sp.str2et("2026-12-01T00:00:00 UTC")
for i in range(61):                               # 30 days, 12 h step (use 600 s in production)
    et, row = et0 + i * 43200.0, []
    for body in ("SUN", "EARTH"):
        azl, lt = sp.azlcpo("ELLIPSOID", body, et, "LT+S", False, True,
                            site, "MOON", "MOON_ME")   # azccw=False: N->E; elplsz=True: up
        row += [np.degrees(azl[1]) % 360.0, np.degrees(azl[2])]
    print(sp.et2utc(et, "ISOC", 0), "Sun az/el %.4f %.4f | Earth az/el %.4f %.4f" % tuple(row))
# Acceptance test vs Horizons (DE441, MEAN_ME), 2026-12-01T00:00:
#   Sun az/el 250.8807 -0.2384 | Earth az/el 337.5024 3.2140  -> expect |diff| < 0.1 arcmin
