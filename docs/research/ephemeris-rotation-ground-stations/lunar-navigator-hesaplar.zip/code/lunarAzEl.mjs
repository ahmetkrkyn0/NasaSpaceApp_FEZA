// Lunar site -> Sun/Earth az/el in the browser with astronomy-engine 2.1.19 (MIT).
// No built-in lunar observer: rotate J2000 vectors with the IAU Moon axis model by hand.
import * as A from "astronomy-engine";
const D = Math.PI / 180, AU = 149597870.7;
const r3 = (a, [x, y, z]) => [Math.cos(a) * x + Math.sin(a) * y, -Math.sin(a) * x + Math.cos(a) * y, z];
const r1 = (a, [x, y, z]) => [x, Math.cos(a) * y + Math.sin(a) * z, -Math.sin(a) * y + Math.cos(a) * z];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
export function lunarAzEl(date, latDeg, lonDeg, R = 1737.4) {
  const t = A.MakeTime(date), ax = A.RotationAxis(A.Body.Moon, t);   // ra [h], dec [deg], spin [deg]
  const bf = v => r3(ax.spin * D, r1((90 - ax.dec) * D, r3((90 + ax.ra * 15) * D, v)));
  const m = A.GeoMoon(t), h = A.HelioVector(A.Body.Moon, t);        // AU, J2000 equatorial
  const la = latDeg * D, lo = lonDeg * D;
  const up = [Math.cos(la) * Math.cos(lo), Math.cos(la) * Math.sin(lo), Math.sin(la)];
  const east = [-Math.sin(lo), Math.cos(lo), 0];
  const north = [-Math.sin(la) * Math.cos(lo), -Math.sin(la) * Math.sin(lo), Math.cos(la)];
  const topo = v => {                                // subtract site position: parallax up to 15.5'
    const d = bf(v).map((c, i) => c - R * up[i]), n = Math.hypot(...d);
    const enu = [dot(d, east) / n, dot(d, north) / n, dot(d, up) / n];
    return { enu, az: (Math.atan2(enu[0], enu[1]) / D + 360) % 360, el: Math.asin(enu[2]) / D, km: n };
  };
  return { sun: topo([-h.x * AU, -h.y * AU, -h.z * AU]), earth: topo([-m.x * AU, -m.y * AU, -m.z * AU]) };
}
// No light-time/aberration: expect ~1' vs Horizons (engine accuracy), Sun aberration adds <=0.34'.
console.log(lunarAzEl(new Date("2026-12-01T00:00:00Z"), -84.78, 29.13));
