import numpy as np, sys
from datetime import datetime, timedelta
D=sys.argv[1]
t0=datetime(2026,12,1)
for f,name in [("hz_earth_site.txt","Earth"),("hz_sun_site.txt","Sun")]:
    el=np.loadtxt(f"{D}/{f}",usecols=2); h=np.arange(len(el))*12.0
    # cubic local interpolation around each sign change
    for i in range(len(el)-1):
        if np.sign(el[i])!=np.sign(el[i+1]):
            j=max(0,min(len(el)-4,i-1)); p=np.polyfit(h[j:j+4],el[j:j+4],3)
            rr=[r.real for r in np.roots(p) if abs(r.imag)<1e-9 and h[i]<=r.real<=h[i+1]]
            kind="rises" if el[i+1]>el[i] else "sets"
            print(name,kind,(t0+timedelta(hours=rr[0])).strftime("%Y-%m-%d %H:%M UTC"))
    print(name,"min/max el",el.min(),el.max())
