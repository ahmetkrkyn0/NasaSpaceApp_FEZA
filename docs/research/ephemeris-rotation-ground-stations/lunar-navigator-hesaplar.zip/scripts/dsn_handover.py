import numpy as np, importlib.util, sys
spec=importlib.util.spec_from_file_location("c","scripts/dsn_coverage.py")
src=open("scripts/dsn_coverage.py").read().split("nets = {")[0]; exec(src)
def gaps(names,dec,D,mask):
    cov=np.any([vis(s,dec,D,mask) for s in names],0)
    if cov.all(): return []
    # locate gaps and which station sets just before / rises just after
    idx=np.where(~cov)[0]; out=[]; starts=[idx[0]]
    for i in range(1,len(idx)):
        if idx[i]!=idx[i-1]+1: starts.append(idx[i])
    for s0 in starts:
        e=s0
        while not cov[(e+1)%len(cov)] and e-s0<len(cov): e+=1
        before=[n for n in names if vis(n,dec,D,mask)[(s0-1)%len(cov)]]
        after=[n for n in names if vis(n,dec,D,mask)[(e+1)%len(cov)]]
        out.append((round((e-s0+1)*0.02/RATE*1440,1),before,after))
    return out
DSN=['DSS-14 Goldstone','DSS-43 Canberra','DSS-63 Madrid']
for mask in (6.0,10.0):
    for dec in (-28.5,-27.6,-20,0,20,27.6):
        print(f"mask {mask} dec {dec:+.1f}:", gaps(DSN,dec,384400,mask))
nets={'DSN+NewNorcia':DSN+['New Norcia'],'DSN+Malargue+NewNorcia':DSN+['Malargue','New Norcia'],
      'DSN+ESTRACK3':DSN+['Malargue','New Norcia','Cebreros'],'DSN+ESTRACK3+IDSN+Misasa':DSN+['Malargue','New Norcia','Cebreros','IDSN Byalalu','Misasa']}
for mask in (6.0,10.0):
    print(f"\nmask {mask}: worst gap over dec -28.5..+28.5 [min]")
    for n,st in nets.items():
        w=max(maxgap(np.any([vis(s,d,384400,mask) for s in st],0)) for d in np.arange(-28.5,28.51,0.5))
        print(f"  {n:28s} {w:6.1f}")
