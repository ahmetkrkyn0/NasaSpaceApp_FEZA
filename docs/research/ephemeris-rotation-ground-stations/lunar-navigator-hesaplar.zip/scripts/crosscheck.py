"""Cross-check Earth/Sun az/el at a lunar site.
M1 = Horizons topocentric (QUANTITIES=4, MEAN_ME/DE441)            -> reference
M2 = Horizons ICRF vectors (LT+S) + IAU_MOON (pck00011) rotation   -> independent orientation model
M3 = Horizons MOON_ME sub-points (q14/q15) + own topocentric math -> same frame, independent ENU math
"""
import numpy as np, sys
D = sys.argv[1]
AU = 149597870.7
LAT, LON, R = np.radians(-84.78), np.radians(29.13), 1737.4

def load(f): return np.loadtxt(f"{D}/{f}", usecols=None, dtype=str)
e1 = np.loadtxt(f"{D}/hz_earth_site.txt", usecols=(1,2,3)); s1 = np.loadtxt(f"{D}/hz_sun_site.txt", usecols=(1,2,3))
sub = np.loadtxt(f"{D}/hz_subpts.txt"); ve = np.loadtxt(f"{D}/vec_earth.txt"); vs = np.loadtxt(f"{D}/vec_sun.txt")
times = np.loadtxt(f"{D}/hz_earth_site.txt", usecols=0, dtype=str)

up = np.array([np.cos(LAT)*np.cos(LON), np.cos(LAT)*np.sin(LON), np.sin(LAT)])
east = np.array([-np.sin(LON), np.cos(LON), 0.0])
north = np.cross(up, east)
site = R*up

def azel(v_bf):                       # v_bf: target position wrt Moon centre, body-fixed, km
    t = v_bf - site; t /= np.linalg.norm(t)
    return np.degrees(np.arctan2(t@east, t@north)) % 360, np.degrees(np.arcsin(t@up))

def azel_geo(v_bf):                   # no parallax (as seen from Moon centre)
    t = v_bf/np.linalg.norm(v_bf); return np.degrees(np.arcsin(t@up))

# ---- IAU_MOON (pck00011) ----
NA = np.array([125.045,-1935.5364525, 250.089,-3871.0729050, 260.008,475263.3328725, 176.625,487269.6299850,
               357.529,35999.0509575, 311.589,964468.4993100, 134.963,477198.8693250, 276.617,12006.3007650,
               34.226,63863.5132425, 15.134,-5806.6093575, 119.743,131.8406400, 239.961,6003.1503825,
               25.053,473327.7964200]).reshape(13,2)
RA = np.array([-3.8787,-0.1204,0.0700,-0.0172,0,0.0072,0,0,0,-0.0052,0,0,0.0043])
DE = np.array([1.5419,0.0239,-0.0278,0.0068,0,-0.0029,0.0009,0,0,0.0008,0,0,-0.0009])
PM = np.array([3.5610,0.1208,-0.0642,0.0158,0.0252,-0.0066,-0.0047,-0.0046,0.0028,0.0052,0.0040,0.0019,-0.0044])
def R1(a): c,s=np.cos(a),np.sin(a); return np.array([[1,0,0],[0,c,s],[0,-s,c]])
def R3(a): c,s=np.cos(a),np.sin(a); return np.array([[c,s,0],[-s,c,0],[0,0,1]])
def iau_moon(jd_tdb):
    d = jd_tdb-2451545.0; T = d/36525.0
    E = np.radians(NA[:,0]+NA[:,1]*T)
    a = 269.9949+0.0031*T+RA@np.sin(E); dd = 66.5392+0.0130*T+DE@np.cos(E)
    W = 38.3213+13.17635815*d-1.4e-12*d*d+PM@np.sin(E)
    return R3(np.radians(W))@R1(np.radians(90-dd))@R3(np.radians(90+a))

rows=[]
for i in range(len(times)):
    M = iau_moon(ve[i,0])
    az2e, el2e = azel(M@ve[i,1:]); az2s, el2s = azel(M@vs[i,1:])
    l,b,ls,bs,dl = np.radians(sub[i,0]),np.radians(sub[i,1]),np.radians(sub[i,2]),np.radians(sub[i,3]),sub[i,4]*AU
    pE = dl*np.array([np.cos(b)*np.cos(l),np.cos(b)*np.sin(l),np.sin(b)])
    pS = s1[i,2]*AU*np.array([np.cos(bs)*np.cos(ls),np.cos(bs)*np.sin(ls),np.sin(bs)])
    az3e, el3e = azel(pE); az3s, el3s = azel(pS)
    rows.append([e1[i,0],e1[i,1],az2e,el2e,az3e,el3e,azel_geo(pE), s1[i,0],s1[i,1],az2s,el2s,az3s,el3s])
r = np.array(rows)
am = lambda x: x*60.0
def wrap(x): return (x+180)%360-180
print("time              | Earth el: HZ    M2-HZ'  M3-HZ' geo(no parallax)-HZ' | Sun el: HZ   M2-HZ'  M3-HZ'")
for t,x in zip(times,r):
    print(f"{t} | {x[1]:8.4f} {am(x[3]-x[1]):7.3f} {am(x[5]-x[1]):7.3f} {am(x[6]-x[1]):7.2f} | {x[8]:8.4f} {am(x[10]-x[8]):7.3f} {am(x[12]-x[8]):7.3f}")
def stats(name,d): print(f"{name:34s} max|d|={np.max(np.abs(d)):.3f}'  mean={np.mean(d):+.3f}'  rms={np.sqrt(np.mean(d*d)):.3f}'")
print()
stats("Earth EL  M2(IAU_MOON)-Horizons", am(r[:,3]-r[:,1])); stats("Earth AZ  M2(IAU_MOON)-Horizons", am(wrap(r[:,2]-r[:,0])))
stats("Earth EL  M3(ME subpts)-Horizons", am(r[:,5]-r[:,1])); stats("Earth AZ  M3(ME subpts)-Horizons", am(wrap(r[:,4]-r[:,0])))
stats("Sun   EL  M2(IAU_MOON)-Horizons", am(r[:,10]-r[:,8])); stats("Sun   AZ  M2(IAU_MOON)-Horizons", am(wrap(r[:,9]-r[:,7])))
stats("Sun   EL  M3(ME subpts)-Horizons", am(r[:,12]-r[:,8])); stats("Sun   AZ  M3(ME subpts)-Horizons", am(wrap(r[:,11]-r[:,7])))
stats("Earth EL  no-parallax - topocentric", am(r[:,6]-r[:,1]))
# sanity: vector range vs Horizons site range
rng = np.linalg.norm(ve[:,1:],axis=1); print("Earth range Moon-centre (vec) min/max km:", rng.min().round(1), rng.max().round(1))
print("Earth EL range (Horizons):", r[:,1].min(), r[:,1].max(), " Sun EL range:", r[:,8].min(), r[:,8].max())
np.savetxt(f"{D}/../crosscheck_out.csv", np.column_stack([r]), delimiter=",", fmt="%.6f",
  header="HZ_azE,HZ_elE,M2_azE,M2_elE,M3_azE,M3_elE,geo_elE,HZ_azS,HZ_elS,M2_azS,M2_elS,M3_azS,M3_elS")
