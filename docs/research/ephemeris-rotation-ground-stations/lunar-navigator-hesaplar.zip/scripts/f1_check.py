import numpy as np
def R_enu_body(s,A,psi):
    s,A,psi=np.radians([s,A,psi])
    z=np.array([np.sin(s)*np.sin(A),np.sin(s)*np.cos(A),np.cos(s)])
    x=np.array([np.sin(psi),np.cos(psi),-np.tan(s)*np.cos(psi-A)]); x/=np.linalg.norm(x)
    y=np.cross(z,x); return np.column_stack([x,y,z])
rng=np.random.default_rng(1); worst=0
for _ in range(2000):
    s,A,psi=rng.uniform(0,35),rng.uniform(0,360),rng.uniform(0,360)
    R=R_enu_body(s,A,psi)
    assert np.allclose(R.T@R,np.eye(3),atol=1e-12) and np.isclose(np.linalg.det(R),1)
    th_up=np.degrees(np.arcsin(R[2,0])); pred=np.degrees(np.arctan(-np.tan(np.radians(s))*np.cos(np.radians(psi-A))))
    worst=max(worst,abs(th_up-pred))
    tilt=np.degrees(np.arccos(R[2,2])); assert abs(tilt-s)<1e-9
    # heading preserved from above
    hz=np.degrees(np.arctan2(R[0,0],R[1,0]))%360; assert abs(((hz-psi+180)%360)-180)<1e-9
    # Euler ZYX
    yaw=np.arctan2(R[1,0],R[0,0]); th=-np.arcsin(R[2,0]); ph=np.arctan2(R[2,1],R[2,2])
    Rz=lambda a:np.array([[np.cos(a),-np.sin(a),0],[np.sin(a),np.cos(a),0],[0,0,1]])
    Ry=lambda a:np.array([[np.cos(a),0,np.sin(a)],[0,1,0],[-np.sin(a),0,np.cos(a)]])
    Rx=lambda a:np.array([[1,0,0],[0,np.cos(a),-np.sin(a)],[0,np.sin(a),np.cos(a)]])
    assert np.allclose(Rz(yaw)@Ry(th)@Rx(ph),R,atol=1e-12)
    assert abs(((np.degrees(yaw)-(90-psi)+180)%360)-180)<1e-9
print("F1 checks passed; max |theta_up - formula| =",worst)
print("tests: s=0,psi=0 ->",np.round(R_enu_body(0,123,0),12).tolist())
print("psi=A ->theta_up",np.degrees(np.arcsin(R_enu_body(12,40,40)[2,0])))
print("cos(6.47deg)=",np.cos(np.radians(6.47)),"sin=",np.sin(np.radians(6.47)))
