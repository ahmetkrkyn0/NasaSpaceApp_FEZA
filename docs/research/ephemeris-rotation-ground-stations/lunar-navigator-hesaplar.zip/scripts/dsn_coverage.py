"""Gap analysis: can ground networks see the Moon continuously, as a function of Moon declination?
Topocentric elevation incl. lunar parallax, WGS84 station positions. Earth-rotation sweep over GHA."""
import numpy as np
a,f = 6378.137, 1/298.257223563; e2 = f*(2-f)
def ecef(lat,lon,h):
    p,l = np.radians(lat),np.radians(lon); N = a/np.sqrt(1-e2*np.sin(p)**2)
    return np.array([(N+h)*np.cos(p)*np.cos(l),(N+h)*np.cos(p)*np.sin(l),(N*(1-e2)+h)*np.sin(p)]), \
           np.array([np.cos(p)*np.cos(l),np.cos(p)*np.sin(l),np.sin(p)])
ST = {  # DSN: 810-005 301 Rev P (WGS84). ESTRACK: estrack_v04.tf. JAXA: ddor.nav.isas.jaxa.jp. ISRO: approx.
 'DSS-14 Goldstone':(35.425901,243.110462,1.001),'DSS-43 Canberra':(-35.402424,148.981267,0.689),
 'DSS-63 Madrid':(40.431210,355.751991,0.865),
 'Malargue':(-35.776,-69.398,1.5),'New Norcia':(-31.048,116.191,0.25),'Cebreros':(40.453,-4.368,0.8),
 'Misasa':(36.140985,138.352129,1.656),'IDSN Byalalu':(12.9016,77.3686,0.8)}
P = {k:ecef(*v) for k,v in ST.items()}
GHA = np.arange(0,360,0.02); RATE = 360.9856-13.176   # deg/day of Moon GHA
def vis(name,dec,D,mask):
    s,up = P[name]; lon_m = np.radians(-GHA); d = np.radians(dec)
    m = D*np.stack([np.cos(d)*np.cos(lon_m),np.cos(d)*np.sin(lon_m),np.full_like(lon_m,np.sin(d))],1)
    v = m-s; el = np.degrees(np.arcsin((v@up)/np.linalg.norm(v,axis=1))); return el>=mask
def maxgap(cov):
    if cov.all(): return 0.0
    c = np.concatenate([cov,cov]); best=run=0
    for x in c:
        run = 0 if x else run+1; best=max(best,run)
    return min(best,len(cov))*0.02/RATE*1440   # minutes
nets = {'DSN (3 kompleks)':['DSS-14 Goldstone','DSS-43 Canberra','DSS-63 Madrid'],
        'DSN + Malargue':['DSS-14 Goldstone','DSS-43 Canberra','DSS-63 Madrid','Malargue'],
        'ESTRACK DSA (3)':['New Norcia','Cebreros','Malargue']}
for D,lab in [(384400,'ortalama'),(356500,'perige'),(406700,'apoje')]:
  for mask in (6.0,10.0):
    print(f"\n--- D={D} km ({lab}), maske={mask} deg: en uzun boşluk [dk] ---")
    print("dec    " + " | ".join(f"{n:>17s}" for n in nets))
    for dec in (-28.5,-28,-27.5,-27,-26,-25,-24,-22,-20,-15,0,15,20,25,28.5):
        print(f"{dec:+5.1f}  " + " | ".join(f"{maxgap(np.any([vis(s,dec,D,mask) for s in st],0)):17.1f}" for st in nets.values()))
# threshold declination where DSN gap appears
for D in (384400,356500,406700):
  for mask in (6.0,10.0):
    decs = np.arange(-30,-10,0.05); g=[maxgap(np.any([vis(s,d,D,mask) for s in nets['DSN (3 kompleks)']],0)) for d in decs]
    thr = [d for d,x in zip(decs,g) if x>0]
    print(f"D={D} mask={mask}: DSN gap begins at dec <= {max(thr):.2f}" if thr else f"D={D} mask={mask}: no gap down to -30")
# Moon declination range in Dec 2026 from Horizons Earth-wrt-Moon vectors
ve=np.loadtxt('data/vec_earth.txt'); m=-ve[:,1:]; dec=np.degrees(np.arcsin(m[:,2]/np.linalg.norm(m,axis=1)))
print("\nDec 2026 Moon geocentric dec range (12h samples):",dec.min().round(2),dec.max().round(2))
# single-station daily visibility hours at extreme dec
for s in ST:
    for dd in (-28.5,0,28.5):
        print(f"{s:18s} dec {dd:+5.1f}: {vis(s,dd,384400,6.0).mean()*24*360.9856/RATE/ (360.9856/RATE):5.2f} h/gün (maske 6°)", end="; ")
    print()
